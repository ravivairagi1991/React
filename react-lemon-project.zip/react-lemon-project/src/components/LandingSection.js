import React from "react";
import { Avatar, Heading, VStack } from "@chakra-ui/react";
import FullScreenSection from "./FullScreenSection";

const greeting = "Hello, I am Pete!";
const bio1 = "A frontend developer";
const bio2 = "specialized in React";

const LandingSection = () => (
<FullScreenSection
justifyContent="center"
alignItems="center"
isDarkBackground
backgroundColor="#2A4365"
>
<Avatar size="xl" src="https://i.pravatar.cc/150?img=7" alt="Profile picture"/>
<Heading
  textAlign="center"
  fontSize="xl"
  mt={8}
  fontWeight="bold"
  color="white"
>
  {greeting}
</Heading>
<VStack mt={4} textAlign="center">
  <Heading fontSize="lg" color="white">
    {bio1}
  </Heading>
  <Heading fontSize="lg" color="white">
    {bio2}
  </Heading>
</VStack>

  </FullScreenSection>
);

export default LandingSection;